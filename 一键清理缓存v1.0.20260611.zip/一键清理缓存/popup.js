/**
 * popup.js —  一键清理缓存
 *
 * 清理项目：浏览历史、缓存、Cookie、下载历史、本地存储
 * 永久保留：已保存密码（passwords）、自动填表信息（formData）
 */

'use strict';

// ─── DOM refs ───────────────────────────────────────────────────────
const timeTabs      = document.querySelectorAll('.time-tab');
const btnSelectAll  = document.getElementById('btnSelectAll');
const btnClean      = document.getElementById('btnClean');
const statusBar     = document.getElementById('statusBar');

// Checkbox ids → browsingData dataType keys
const DATA_TYPES = {
  history:      'history',
  cache:        'cache',
  cookies:      'cookies',
  downloads:    'downloads',
  localStorage: 'localStorage',
};

let selectedSince = 3600000; // default: last 1 hour (ms)

// ─── Time tab selection ──────────────────────────────────────────────
timeTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    timeTabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    selectedSince = parseInt(tab.dataset.value, 10);
  });
});

// ─── Select all toggle ────────────────────────────────────────────────
let allSelected = true;

btnSelectAll.addEventListener('click', () => {
  allSelected = !allSelected;
  Object.keys(DATA_TYPES).forEach(id => {
    document.getElementById(id).checked = allSelected;
  });
  btnSelectAll.textContent = allSelected ? '全选' : '取消';
});

// ─── Status helper ────────────────────────────────────────────────────
function showStatus(type, message) {
  statusBar.className = `status-bar show ${type}`;
  if (type === 'loading') {
    statusBar.innerHTML = `<div class="spinner"></div><span>${message}</span>`;
  } else {
    const icon = type === 'success'
      ? '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" fill="currentColor"/></svg>'
      : '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z" fill="currentColor"/></svg>';
    statusBar.innerHTML = `${icon}<span>${message}</span>`;
  }
}

function hideStatus() {
  statusBar.className = 'status-bar';
}

// ─── Main clean action ────────────────────────────────────────────────
btnClean.addEventListener('click', async () => {
  // Collect checked types
  const dataToRemove = {};
  let hasSelection = false;

  Object.entries(DATA_TYPES).forEach(([id, typeKey]) => {
    const checked = document.getElementById(id).checked;
    dataToRemove[typeKey] = checked;
    if (checked) hasSelection = true;
  });

  if (!hasSelection) {
    showStatus('error', '请至少选择一个清理项目');
    setTimeout(hideStatus, 2500);
    return;
  }

  // Calculate since timestamp
  const since = selectedSince === 0
    ? 0
    : Date.now() - selectedSince;

  btnClean.disabled = true;
  showStatus('loading', '正在清理中，请稍候...');

  try {
    await chrome.browsingData.remove(
      { since },
      dataToRemove
      // NOTE: passwords & formData are intentionally OMITTED
      // chrome.browsingData.remove only clears types you explicitly list,
      // so passwords and autofill form data are never touched.
    );

    // Also clear history via history API if history is selected
    if (dataToRemove.history && chrome.history) {
      const startTime = since || 0;
      await chrome.history.deleteRange({
        startTime,
        endTime: Date.now(),
      });
    }

    const labels = [];
    if (dataToRemove.history)      labels.push('浏览历史');
    if (dataToRemove.cache)        labels.push('缓存');
    if (dataToRemove.cookies)      labels.push('Cookie');
    if (dataToRemove.downloads)    labels.push('下载历史');
    if (dataToRemove.localStorage) labels.push('本地存储');

    showStatus('success', `已清理：${labels.join('、')}`);
    setTimeout(hideStatus, 3500);
  } catch (err) {
    console.error('[ 一键清理缓存] 清理失败:', err);
    showStatus('error', `清理失败：${err.message || '未知错误'}`);
    setTimeout(hideStatus, 4000);
  } finally {
    btnClean.disabled = false;
  }
});
