/**
 * background.js — Chrome 扩展 Service Worker
 *
 * 点击工具栏图标 → 立即清理（无弹窗）
 * 清理范围：浏览历史、Cookie、缓存、本地存储（全部时间）
 * 永久保留：密码（passwords）、自动填表（formData）、下载记录（downloads）
 */

'use strict';

// ─── 点击工具栏图标时触发 ───────────────────────────────
chrome.action.onClicked.addListener((tab) => {
  cleanNow();
});

// ─── 核心清理逻辑 ───────────────────────────────────────
async function cleanNow() {
  // 余弦徽章图标：清理中（旋转 + 沙漏）
  chrome.action.setBadgeText({ text: '...' });
  chrome.action.setBadgeBackgroundColor({ color: '#4361ee' });

  try {
    // since: 0 = 全部时间
    await chrome.browsingData.remove(
      { since: 0 },
      {
        // ✅ 要清理的类型
        cache:        true,   // 缓存的图片和文件
        cookies:     true,   // Cookie 及其他网站数据
        history:      true,   // 浏览记录
        localStorage: true,   // 本地存储

        // ❌ 绝对不清理的类型（白名单机制，不列 = 不清理）
        // passwords:  false,  ← 不传 = 不清理
        // formData:  false,  ← 不传 = 不清理
        // downloads: false,  ← 不传 = 不清理
      }
    );

    // 同时用 history API 完整清除（更彻底）
    await chrome.history.deleteRange({ startTime: 0, endTime: Date.now() });

    // 清理成功：绿色 ✓
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#16a34a' });
    console.log('[一键清理缓存] 清理完成');

    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2500);

  } catch (err) {
    // 清理失败：红色 ✗
    console.error('[ 一键清理缓存] 清理失败:', err);
    chrome.action.setBadgeText({ text: '✗' });
    chrome.action.setBadgeBackgroundColor({ color: '#dc2626' });
    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 3000);
  }
}

// ─── 安装提示 ───────────────────────────────────────────
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === 'install') {
    console.log('[一键清理缓存] 已安装 — 点击工具栏图标即可一键清理');
    console.log('[一键清理缓存] 密码、自动填表、下载记录永远不会被清理');
  }
  if (reason === 'update') {
    console.log('[一键清理缓存] 已更新至 v1.1.0');
  }
});
